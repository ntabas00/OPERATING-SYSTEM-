
import threading
import logging


class VirtualMemoryManager(threading.Thread):
    #constructor
    def __init__(self, mainMem, commandList, clock, disk):
        super(VirtualMemoryManager, self).__init__()
        self.mainMemory = mainMem
        self.cmdList = commandList
        self.clockTime = clock
        self.diskMemory = disk
        self.stopThread = False
        self.lock = threading.Lock()
        # self.configureThreadMsg()


    def configureThreadMsg(self):
        #configure logging info format
        logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process %(processId)s: %(message)s')
        # logging.basicConfig(filename='output.txt', level=logging.INFO,
        #                     format='Time %(time)s, User %(user)s, Process %(processId)s, %(message)s')
        #
        # extra_info = {'time': self.t1.timer, 'user': p.user, 'processId': p.id}
        # logging.info('Started', extra=extra_info)



    #store api call
    def store(self, id, val):
        if self.mainMemory.isFullMemory() == False:
            self.mainMemory.storeMemory(id, val)
        else:
            self.diskMemory.addVariable(id, val)


    #release api call
    def release(self, id):
        varIdx = self.mainMemory.findVariableMemory(id)
        if varIdx == -1:
            if self.diskMemory.checkVariable(id):
                self.diskMemory.removeVariable(id)
            else:
                print("cmd Release "+ id + " cannot be executed. " + id + " is not found")
        else:
            self.mainMemory.removeMemory(varIdx)


    def lookup(self, id, processId):
        id = str(id)
        idx = self.mainMemory.findVariableMemory(id)
        print("idx = "+ str(idx))
        if idx != -1:
            # return self.mainMemory[idx][1]
            val = str(self.mainMemory.getVarValue(id))
            print("Lookup value in main: "+ val)
            return val
        else:
            print(self.diskMemory.checkVariable(id))
            if self.diskMemory.checkVariable(id):
                val = str(self.swap(id, processId))
                print("Lookup value in disk " + val)
                return val



    def swap(self, id, processId):
        id = str(id)

        val = str(self.diskMemory.getValue(id))

        lastAccessIdx = self.mainMemory.getLastAccessIdx()
        temp = self.mainMemory.getLastAccessVar()
        lastAccVariable = temp[0]
        lastAccValue = temp[1]

        print("Var to be swapped: "+ str(lastAccVariable) + " " + str(lastAccValue))


        #remove from lookup var from disk
        self.diskMemory.removeVariable(id)
        #remove swapped var from the main memory
        self.mainMemory.removeMemory(lastAccessIdx)
        #add the swapped var to the disk
        self.diskMemory.addVariable(lastAccVariable, lastAccValue)
        #add lookup var to the main memory
        self.mainMemory.storeMemory(id, val)

        print("Current: " + str(id) + " " + str(val))

        logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process Id: %(processId)s, %(message)s')
        extra_info = {'time': self.clockTime.getClock(), 'processId': processId}
        logging.info(f'Swap: Variable {str(int(id))} with Variable {lastAccVariable}', extra=extra_info)

        return val


    def setStopThread(self, stop):
        self.stopThread = stop


    def api(self, cmd, processId, endTime):
        logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process %(processId)s: %(message)s')

        self.lock.acquire()

        if cmd[0] == "Store":
            self.store(cmd[1], cmd[2])

            extra_info = {'time': self.clockTime.getClock(), 'processId': processId}
            logging.info(f' {cmd[0]}: Variable {cmd[1]}, Value: {cmd[2]}', extra=extra_info)
        elif cmd[0] == "Lookup":
            val = self.lookup(cmd[1], processId)

            extra_info = {'time': self.clockTime.getClock(), 'processId': processId}
            logging.info(f' {cmd[0]}: Variable {int(cmd[1])}, Value: {val}', extra=extra_info)
        elif cmd[0] == "Release":
            self.release(cmd[1])

            extra_info = {'time': self.clockTime.getClock(), 'processId': processId}
            logging.info(f' {cmd[0]}: Variable {cmd[1]}', extra=extra_info)
        else:
            print("Error. Invalid command input.")


        self.lock.release()

        # logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process %(processId)s: %(message)s')
        #logging
        # extra_info = {'time': self.clockTime.getClock(), 'processId': processId}
        # logging.info('vmmthread', extra=extra_info)
        # logging.info(' {cmd[0]}: Variable {cmd[1]}, Value {}', extra=extra_info)
