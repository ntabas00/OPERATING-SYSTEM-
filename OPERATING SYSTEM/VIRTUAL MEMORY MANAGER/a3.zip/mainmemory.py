


class MainMemory:
    #[[var, val, access], [var, val, access]]
    def __init__(self, numpage):
        self.numPages = numpage
        self.mainMemory = []
        self.lastAccessIdx = None

        #initalize mainMemory
        for i in range(numpage):
            self.mainMemory.append([None])
        #[[None], [None]]


    #check if mainMemory is full
    def isFullMemory(self):
        for x in self.mainMemory:
            if x == [None]:
                return False
        return True


    #store variable id, value and last access
    def storeMemory(self, id, val):
        for x in range(len(self.mainMemory)):
            if self.mainMemory[x] == [None]:
                self.setLastAccessIdx(x)
                print("add to main mem: " +str(int(id)) + " " + str(int(val)))
                self.mainMemory[x] = [id, val]
                break


    #free main memory space with variable id
    def freeMemory(self, id):
        for x in range(len(self.mainMemory)):
            if self.mainMemory[x][0] == id:
                self.mainMemory[x] = [None]
                break

    #free main memory with index
    def removeMemory(self, idx):
        self.mainMemory[idx] = [None]


    #find variable and return index
    def findVariableMemory(self, id):
        for x in range(len(self.mainMemory)):
            print(str(int(self.mainMemory[x][0])) + " cmp to " + str(int(id)))
            if int(self.mainMemory[x][0]) == int(id):
                self.setLastAccessIdx(x)
                return x
        return -1


    def getVarValue(self, id):
        for x in range(len(self.mainMemory)):
            if self.mainMemory[x][0] == id:
                print(self.mainMemory[x])
                return self.mainMemory[x][1]




    def getNumPages(self):
        return self.numPages


    def getLastAccessIdx(self):
        return self.lastAccessIdx

    def getLastAccessVar(self):
        return self.mainMemory[self.lastAccessIdx]

    #setters
    def setNumPages(self, p):
        self.numPages = p

    def setLastAccessIdx(self, access):
        self.lastAccessIdx = access


