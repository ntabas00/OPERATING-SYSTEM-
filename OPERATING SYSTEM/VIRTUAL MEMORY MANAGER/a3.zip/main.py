
import threading
# import time
#
from Clock import Clock
from processes import Process
from scheduler import Scheduler
from mainmemory import MainMemory
from vmm import VirtualMemoryManager
from disk import Disk


if __name__ == '__main__':

    processQueue = []
    commandQueue = []
    #numCores
    #numProcess
    #memPages



    with open("processes.txt", 'r') as processData:
        #number of cores
        numCores = int(processData.readline())
        #number of processes
        numProcess = int(processData.readline())


        # store rest of data
        idValue = 1
        for line in processData:
            data = line.split(" ")
            temp = []
            temp.append(int(data[0]))
            temp.append(int(data[1]))
            temp.append(idValue)
            processQueue.append(temp)
            idValue+=1

        # [[2, 3, 1], [1, 2, 2], [4, 3, 3]

        # sort processQueue
        processQueue.sort()
        # [[1, 2, 2], [2, 3, 1], [4, 3, 3]]


        #close processes file
        processData.close()




        #command list
        with open("commands.txt", 'r') as cmdData:
            for line in cmdData:
                data = line.split(" ")
                commandQueue.append(data)

        #close command file
        cmdData.close()

        # [[Store, 1, 5], [Store, 2, 3], [Store, 3, 7], [Lookup, 3],
        # [Lookup, 2], [Release 1], [Store, 1, 8], [Lookup, 1]]



        #number of pages in main memory
        with open("memconfig.txt", 'r') as memconfig:
            memPages = int(memconfig.readline())
        memconfig.close()


        #open output file
        output_file = open('output.txt', 'w')


        #open vm text file for disk memory
        vm_file = open('vm.txt', 'w')
        vm_file.close()


        #initialize clock
        timeThread = Clock()


        #initialize virtual memory
        # main memory
        main_memory = MainMemory(memPages)
        # disk memory
        disk = Disk()

        #initialize virtual memory manager thread
        threadManager = VirtualMemoryManager(main_memory, commandQueue, timeThread, disk)
        threadManager.start()





        #initialize scheduler
        # def __init__(self, clock, cores, vmm, cmd, processes):
        threadScheduler = Scheduler(timeThread, numCores, threadManager, commandQueue, processQueue)
        threadScheduler.start()


        #do we create threads of the process here or in scheduler
        threadScheduler.threadProcess()


        #set state as true and join threads
        timeThread.setStopThread(True)
        timeThread.join()

        threadManager.setStopThread(True)
        threadManager.join()

        threadScheduler.setStopThread(True)
        threadScheduler.join()



        output_file.close()




