
import time
import threading
from random import Random
import logging



class Process(threading.Thread):
    #attribute const
    # def __init__(self, id, procList, cmdList, vmm, clock, start, duration):
    def __init__(self, id, duration, numRunProcess, cmdList, vmm, clock, start):
        super(Process, self).__init__()
        self.processId = id
        # self.processList = procList
        self.numRunProcess = numRunProcess
        self.commandList = cmdList
        self.vmManager = vmm
        self.stopThread = False
        self.clockTime = clock
        self.startTime = start
        self.durationTime = duration
        self.endTime = self.startTime + self.durationTime
        self.rdmIncrem = Random()

        self.lock = threading.Lock()
        # self.semaphore = threading.Semaphore()



    def run(self):
        # self.clockTime.setClock(self.startTime)
        #/////////////////
        # logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process %(processId)s: %(message)s')
        #loggingprint thread started
        logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process %(processId)s: %(message)s')
        extra_info = {'time': self.clockTime.getClock(), 'processId': self.processId}
        logging.info('Started.', extra=extra_info)

        self.numRunProcess[0] += 1

        #
        while((self.clockTime.getClock() < self.endTime) or (self.stopThread == True)):
            if len(self.commandList) != 0:
                self.runCommand()

        logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process %(processId)s: %(message)s')
        #logginprint thread finished
        extra_info = {'time': self.clockTime.getClock(), 'processId': self.processId}
        logging.info('Finished.', extra=extra_info)


        # #remove process from processList
        # for x in range(len(self.processList)):
        #     if self.processList[x][0] == self.processId:
        #         self.processList.pop(x)
        #         break





    def runCommand(self):

        self.lock.acquire()
        # self.semaphore.acquire()

        waitTime = min(self.endTime - self.clockTime.getClock(), self.rdmIncrem.randrange(10,1000)) /1000

        # waitTime = min((self.endTime - self.clockTime.getClock())/1000, Random.randint(1, 9) * 100)


        if waitTime <= 0:
            self.setStopThread(True)
        else:
            time.sleep(waitTime)
            if ((self.endTime - self.clockTime.getClock()) > 600):

                if len(self.commandList) != 0:
                    cmd = self.commandList.pop(0)
                    # def __init__(self, mainMem, commandList, clock, disk)
                    self.vmManager.api(cmd, self.processId, self.endTime)
                else:
                    print("Done")



        self.lock.release()




    def setStopThread(self, stop):
        self.stopThread = stop


    #setters
    def setProcessId(self,id):
        self.processId = id

    def setArrival(self, arr):
        self.arrival = arr

    def setBurst(self, b):
        self.burst = b

    def setState(self, stat):
        self.state = stat

    def setTimer(self, t):
        self.clockTime = t


    #getters
    def getProcessId(self):
        return self.processId

    def getArrival(self):
        return self.arrival

    def getBurst(self):
        return  self.burst

    def getState(self):
        return self.state

    def getClockTime(self):
        return self.clockTime
