

class Disk:
    def __init__(self):
        self.test = "helloo"

    #check if variable exists and return data
    #if variable exists, it updates the data with its new value
    def updateVariable(self, var):
        with open('vm.txt', 'r') as diskMemory:
            data = []
            for line in diskMemory:
                if int(var.split()[0]) == int(line.split()[0]):
                    data.append(var)
                else:
                    data.append(line)
        diskMemory.close()
        return data

        # with open('vm.txt', 'w') as diskMemory:
        #     for x in range(len(data)):
        #         diskMemory.write(data[x])
        # diskMemory.close()


    #add variable to disk
    # def addVaribale(self, process):
    def addVariable(self, id, val):
        # str = ""
        # for x in process:
        #     self.str += x
        string = str(id) + " " + str(val)


        if self.checkVariable(id):
            data = self.updateVariable(string)
            with open('vm.txt', 'w') as diskMemory:
                for x in range(len(data)):
                    diskMemory.write(data[x])
                    print("add to disk: if exist, updated: "+ data[x])
        else:
            with open('vm.txt', 'a') as diskMemory:
                print("add to disk: "+ string)
                diskMemory.write(string)
        diskMemory.close()



    #find variable in disk
    def checkVariable(self, id):
        with open('vm.txt', 'r') as diskMemory:
            for line in diskMemory:
                # print(str(int(line.split()[0])) + " id: "+ str(int(id)))
                if int(line.split()[0]) == int(id):
                    return True
        return False


    def removeVariable(self, id):
        with open('vm.txt', 'r') as diskMemory:
            data = []
            for line in diskMemory:
                if line.split()[0] != id:
                    data.append(line)
        diskMemory.close()

        with open('vm.txt', 'w') as diskMemory:
            for x in range(len(data)):
                diskMemory.write(data[x])
        diskMemory.close()


    def getValue(self, id):
        with open('vm.txt', 'r') as diskMemory:
            for line in diskMemory:
                if int(line.split()[0]) == int(id):
                    return line.split()[1]
        diskMemory.close()
