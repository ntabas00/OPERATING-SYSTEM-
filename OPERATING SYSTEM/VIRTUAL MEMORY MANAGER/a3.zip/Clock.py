
import time
import threading

class Clock(threading.Thread):

    def __init__(self):
        super(Clock, self).__init__()
        #variable
        self.clock = 0
        self.stopThread = False




    #thread running
    def run(self):
        time.sleep(0.1)

        while not self.stopThread:

            time.sleep(0.1)
            self.clock += 100

            print(self.clock)


    def setStopThread(self, stop):
        self.stopThread = stop

    def setClock(self, t):
        self.clock = t
        # time.sleep(t/1000)


    def getClock(self):
        return int(round(self.clock/10)*10)

