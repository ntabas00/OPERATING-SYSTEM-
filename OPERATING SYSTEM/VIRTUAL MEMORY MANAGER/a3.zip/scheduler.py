

from processes import Process
import threading
import logging

class Scheduler(threading.Thread):
    #constructor
    def __init__(self, clock, cores, vmm, cmd, processes):
        super(Scheduler, self).__init__()
        #attributes
        self.clockTimer = clock
        self.time = 0
        self.numCores = cores
        self.cmdList = cmd
        self.vmmManager = vmm
        self.processList = processes
        self.stopThread = False
        self.numRunProcess = [0]
        self.configureThreadMsg()



    def configureThreadMsg(self):
        #configure logging info format
        logging.basicConfig(filename='output.txt', level=logging.INFO, format='Clock: %(time)s, Process %(processId)s: %(message)s')


    #create process threads
    def threadProcess(self):
        #start clock
        self.clockTimer.start()

        while(True):
            time = self.clockTimer.getClock()

            if len(self.processList) != 0:
                process = self.processList[0]
                #check time
                if (process[0]*1000) <= time and (self.numRunProcess[0] < self.numCores):
                    #def __init__(self, id, procList, commandList, vmm, clock, start, duration):
                    # threadProcess = Process(process[-1], self.processList, self.cmdList, self.vmmManager, self.clockTimer, time, process[1]*1000)
                    # def __init__(self, id, duration, numActive, cmdList, vmm, clock, start):
                    threadProcess = Process(process[-1], process[1]*1000, self.numRunProcess, self.cmdList, self.vmmManager, self.clockTimer, time)
                    threadProcess.start()

                    self.numRunProcess[0]-=1
                    self.processList.pop(0)

            if self.numRunProcess == 0 and len(self.processList) == 0:
                break



    #setters
    def setStopThread(self, stop):
        self.stopThread = stop


